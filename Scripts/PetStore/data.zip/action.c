Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_url("nservice", 
		"URL=http://192.168.100.239:7678/nservice/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("A-IM", 
		"x-bm,gzip");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=112", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Origin", 
		"chrome-extension://nkbihfbeogaeaoehlefnkodbefgpgknn");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("sec-ch-ua", 
		"\"Chromium\";v=\"112\", \"Google Chrome\";v=\"112\", \"Not:A-Brand\";v=\"99\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_custom_request("envelope", 
		"URL=https://sentry.io/api/273505/envelope/?sentry_key=3567c198f8a8412082d32655da2961d0&sentry_version=7", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body={\"sent_at\":\"2023-05-05T12:48:44.092Z\",\"sdk\":{\"name\":\"sentry.javascript.browser\",\"version\":\"6.13.3\"}}\n{\"type\":\"session\"}\n{\"sid\":\"5bb9eb367e6b4702a3a66dfc7e6738e0\",\"init\":true,\"started\":\"2023-05-05T12:48:44.092Z\",\"timestamp\":\"2023-05-05T12:48:44.092Z\",\"status\":\"ok\",\"errors\":0,\"attrs\":{\"release\":\"10.29.0\",\"environment\":\"production\",\"user_agent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 "
		"Safari/537.36\"}}", 
		LAST);

	web_url("posts.json", 
		"URL=https://darkreader.org/blog/posts.json", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("petstore.octoperf.com", 
		"URL=https://petstore.octoperf.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("SMSV=ADHTe-A__3tJ7hlD00zdsWX1jZf30vaSUxPu83hqslAsDT7_SdM3xWcp4O4dQzVGfR0ZGpQyJS13rhqEBRXseZ1m0j3tldtZ2t3HMjGPpee7O6ncOss5qB0; DOMAIN=accounts.google.com");

	web_add_cookie("HSID=AMRq8M9eNX5YiL2Tt; DOMAIN=accounts.google.com");

	web_add_cookie("SSID=Aeso3HHfy0rQ3T_Ic; DOMAIN=accounts.google.com");

	web_add_cookie("APISID=9ChdZ5Nwl-jx3Nwd/A5i43NokNE2qD3hqR; DOMAIN=accounts.google.com");

	web_add_cookie("SAPISID=v4DMMdOxGSRj8Ltw/AAKGkEhY_SAg7bIIV; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-1PAPISID=v4DMMdOxGSRj8Ltw/AAKGkEhY_SAg7bIIV; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PAPISID=v4DMMdOxGSRj8Ltw/AAKGkEhY_SAg7bIIV; DOMAIN=accounts.google.com");

	web_add_cookie("ACCOUNT_CHOOSER=AFx_qI6-qEFtwPHMk09GGcSwVdl2UBsg1y-zDrox4Jf_E0myMoKg9npzxCv79AsLJboVxe_CUQJOSMdEIbI5Xa3c-1vMQ3NeN4cZP0IW-qweIcFvyj-7OPoglttDbGel5E9a0bLa-7-e-lbITDvANjHI7kse5nIAng; DOMAIN=accounts.google.com");

	web_add_cookie("ajs_user_id=qRkl803NpuQIAic3F5Vc3nUgwki1; DOMAIN=accounts.google.com");

	web_add_cookie("ajs_anonymous_id=cd27dae0-73c8-4c60-b1a9-4f2dd8784f39; DOMAIN=accounts.google.com");

	web_add_cookie("user_id=106440561974548956629; DOMAIN=accounts.google.com");

	web_add_cookie("GEM=CgptaW51dGVtYWlkEK2gsLj1MA==; DOMAIN=accounts.google.com");

	web_add_cookie("SID=VAhh9KyI2OoZ-h7MwddE7HEKutBIUfkNTr4u2w0zBFYoPuNPVscCVM6j29kI5ttNT-RIBw.; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-1PSID=VAhh9KyI2OoZ-h7MwddE7HEKutBIUfkNTr4u2w0zBFYoPuNP3JYF-Hofja4Bet5gL78h-w.; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PSID=VAhh9KyI2OoZ-h7MwddE7HEKutBIUfkNTr4u2w0zBFYoPuNP1Ke3J8SD4nuYAjevouyAvA.; DOMAIN=accounts.google.com");

	web_add_cookie("S=billing-ui-v3=HW6qN_RO3Nm566cwFqjL5Wx0dlKsOrTI:billing-ui-v3-efe=HW6qN_RO3Nm566cwFqjL5Wx0dlKsOrTI; DOMAIN=accounts.google.com");

	web_add_cookie("LSID=o.drive.google.com|o.groups.google.com|o.mail.google.com|o.meet.google.com|o.myaccount.google.com|o.play.google.com|o.remotedesktop.google.com|o.takeout.google.com|s.BR|s.youtube:Vwhh9CxC_ziDSyy5cuBFM0xWr7acd3dHSELbZjcrUHGguTFvLQbVhJkBy5uCG_oLvC33LQ.; DOMAIN=accounts.google.com");

	web_add_cookie("__Host-1PLSID=o.drive.google.com|o.groups.google.com|o.mail.google.com|o.meet.google.com|o.myaccount.google.com|o.play.google.com|o.remotedesktop.google.com|o.takeout.google.com|s.BR|s.youtube:Vwhh9CxC_ziDSyy5cuBFM0xWr7acd3dHSELbZjcrUHGguTFvcQRGN7Csgdzh0E-WY1aMxw.; DOMAIN=accounts.google.com");

	web_add_cookie("__Host-3PLSID=o.drive.google.com|o.groups.google.com|o.mail.google.com|o.meet.google.com|o.myaccount.google.com|o.play.google.com|o.remotedesktop.google.com|o.takeout.google.com|s.BR|s.youtube:Vwhh9CxC_ziDSyy5cuBFM0xWr7acd3dHSELbZjcrUHGguTFvXphi8kw-BR92c_EF6yDSVQ.; DOMAIN=accounts.google.com");

	web_add_cookie("SEARCH_SAMESITE=CgQIl5gB; DOMAIN=accounts.google.com");

	web_add_cookie("NID=511=PTySMt1g-lt2F3uIE3yuGiNOtaRLyxistG97Kh5R-YDjiDSaO2E13DyRP-dOGCYpGYg9xsDqEk4cJWYoRjeY8kjQRaWdv2y-VpbT9YkLJqEdnwREkf_DbnxAYelb9oOhXLAQ9IXCbNQ0cGPbn3OE0c6Y8npN8TNCtf5iEfiETbUK816oew2HeX3AjhR2_8oQwfSTXNWNfKyCmJWy5HSuOp4vo_yUJeRoL5u0mMCY6_gde9jY_5hUSDNL_OuzpD_KiMLPCOtGAyQ; DOMAIN=accounts.google.com");

	web_add_cookie("__Host-GAPS=1:YDgbxbid4MX7muyWDHUSBK7-YCnDPNfoshBaWt_uqhrJYDXFiNS_w98K9uguAzvlO9GUe5AYKq22uoJQIuGlE7E6yrju9A:yNL5s__-xrmP5S-M; DOMAIN=accounts.google.com");

	web_add_cookie("1P_JAR=2023-05-05-12; DOMAIN=accounts.google.com");

	web_add_cookie("AEC=AUEFqZdnwAuUYQ79lEzSdAIjtYjulQMwdBkC9jNiZcz4HB3eRAD8gReK9yY; DOMAIN=accounts.google.com");

	web_add_cookie("SIDCC=AP8dLtxWXnmA-GekjQPE0EftJqRVouz0p0JGhjSH-0NliJrxHdx3E5EN-RTfgezHIeqmNhlJZg; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-1PSIDCC=AP8dLtxgPg0HRwHVDw82Upa6xzzMS2853eA9K1kXNw2rUVsS-DqOzMqPnD2TPf93Wu66mJsNbmc; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PSIDCC=AP8dLtzCADTvfDVcWe3BzNmdG30QHQJStIRtAvXctHbM81ytuMLGXoPeUytCPR7c9eQNTsIiWJs; DOMAIN=accounts.google.com");

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_header("Origin", 
		"https://www.google.com");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_custom_request("ListAccounts", 
		"URL=https://accounts.google.com/ListAccounts?gpsia=1&source=ChromiumBrowser&json=standard", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"Body= ", 
		LAST);

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	web_custom_request("token", 
		"URL=https://www.googleapis.com/oauth2/v4/token", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"Body=client_id=77185425430.apps.googleusercontent.com&client_secret=OTJgUOQcT7lO7GsGZq2G4IlT&grant_type=refresh_token&refresh_token=1//01HjdBhywwBvOCgYIARAAGAESNwF-L9IrKiGe3OzJMDfZUv4w8GXat3s03ucdFRHj7q3Jndp-edw34SiBZuKIAN3hO9e-_jH0bAg&scope=https://www.googleapis.com/auth/chromesync", 
		LAST);

	return 0;
}